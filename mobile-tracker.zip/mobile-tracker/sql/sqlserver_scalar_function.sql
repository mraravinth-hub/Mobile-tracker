-- ============================================================
-- SQL Server / T-SQL version of the schema + scalar functions
-- (Use this if you want to run the project on SQL Server instead of SQLite)
-- ============================================================

CREATE TABLE devices (
    id          INT IDENTITY(1,1) PRIMARY KEY,
    name        NVARCHAR(60)  NOT NULL,
    token       VARCHAR(64)   NOT NULL UNIQUE,
    consent_at  DATETIME2     NOT NULL,
    created_at  DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE locations (
    id          BIGINT IDENTITY(1,1) PRIMARY KEY,
    device_id   INT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    lat         FLOAT NOT NULL,
    lon         FLOAT NOT NULL,
    accuracy    FLOAT NULL,
    battery     FLOAT NULL,
    recorded_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX idx_loc_device_time ON locations(device_id, recorded_at DESC);
GO

-- Scalar function 1: great-circle distance in meters
CREATE OR ALTER FUNCTION dbo.fn_Haversine
(
    @lat1 FLOAT, @lon1 FLOAT, @lat2 FLOAT, @lon2 FLOAT
)
RETURNS FLOAT
AS
BEGIN
    DECLARE @R FLOAT = 6371000;
    DECLARE @dLat FLOAT = RADIANS(@lat2 - @lat1);
    DECLARE @dLon FLOAT = RADIANS(@lon2 - @lon1);
    DECLARE @a FLOAT =
        POWER(SIN(@dLat / 2), 2) +
        COS(RADIANS(@lat1)) * COS(RADIANS(@lat2)) * POWER(SIN(@dLon / 2), 2);
    RETURN 2 * @R * ASIN(SQRT(@a));
END;
GO

-- Scalar function 2: speed in km/h
CREATE OR ALTER FUNCTION dbo.fn_SpeedKmh (@meters FLOAT, @seconds FLOAT)
RETURNS FLOAT
AS
BEGIN
    RETURN CASE WHEN @seconds IS NULL OR @seconds <= 0 THEN NULL
                ELSE (@meters / @seconds) * 3.6 END;
END;
GO

-- Scalar function 3: online status (1/0)
CREATE OR ALTER FUNCTION dbo.fn_IsOnline (@lastSeen DATETIME2, @thresholdSeconds INT)
RETURNS BIT
AS
BEGIN
    RETURN CASE WHEN @lastSeen IS NOT NULL
                 AND DATEDIFF(SECOND, @lastSeen, SYSUTCDATETIME()) <= @thresholdSeconds
                THEN 1 ELSE 0 END;
END;
GO

-- ---------------- Example queries ----------------

-- Latest position of each device + online flag
SELECT d.id, d.name, l.lat, l.lon, l.recorded_at,
       dbo.fn_IsOnline(l.recorded_at, 120) AS is_online
FROM devices d
OUTER APPLY (SELECT TOP 1 * FROM locations WHERE device_id = d.id ORDER BY recorded_at DESC) l;

-- Total distance travelled by device 1 in the last 24 hours
WITH ordered AS (
    SELECT lat, lon, recorded_at,
           LAG(lat) OVER (ORDER BY recorded_at) AS plat,
           LAG(lon) OVER (ORDER BY recorded_at) AS plon
    FROM locations
    WHERE device_id = 1 AND recorded_at >= DATEADD(HOUR, -24, SYSUTCDATETIME())
)
SELECT SUM(dbo.fn_Haversine(plat, plon, lat, lon)) AS distance_m
FROM ordered WHERE plat IS NOT NULL;

-- Devices within 1 km of a point (Chennai Central)
SELECT d.name, dbo.fn_Haversine(13.0827, 80.2707, l.lat, l.lon) AS distance_m
FROM devices d
CROSS APPLY (SELECT TOP 1 * FROM locations WHERE device_id = d.id ORDER BY recorded_at DESC) l
WHERE dbo.fn_Haversine(13.0827, 80.2707, l.lat, l.lon) <= 1000;
