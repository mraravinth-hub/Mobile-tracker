process.env.DB_FILE = ':memory:';
const assert = require('assert');
const db = require('../db');

// Chennai Central -> Marina Beach is roughly 3.3 km
const d = db.prepare('SELECT haversine(13.0827, 80.2707, 13.0500, 80.2824) AS m').get().m;
assert(d > 3000 && d < 4200, 'haversine out of range: ' + d);

assert.strictEqual(db.prepare('SELECT haversine(NULL, 1, 2, 3) AS m').get().m, null);
assert.strictEqual(Math.round(db.prepare('SELECT speed_kmh(1000, 100) AS s').get().s), 36);
assert.strictEqual(db.prepare('SELECT is_online(?, 120) AS o').get(Date.now()).o, 1);
assert.strictEqual(db.prepare('SELECT is_online(?, 120) AS o').get(Date.now() - 10 * 60 * 1000).o, 0);

console.log('All scalar function tests passed. haversine =', Math.round(d), 'm');
